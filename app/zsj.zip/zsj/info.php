<?php
return array (
	'name'	=> '植树节2048',
	'ver'	=> '1.0',
	'ico' => '&#xe857;',
	'desc'	=> '植树节2048',
	'email' => 'cnyzzy@qq.com',
	'author' => 'ZY',
	'author_url' => 'http://echo1.top',
	'admin'	=> '1',
	'install'	=> '1',
	'show'	=> '1',
	'sql' => '0',
	'system'	=> '0',
	'son'	=> '0',
);
?>