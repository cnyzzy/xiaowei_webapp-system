<?php
if(!is_dir(ZSystem.'/data/app/zsj') )mkdir(ZSystem.'/data/app/zsj');
	$number=$_SESSION['zid']['number'];
	$type=$_SESSION['zid']['type'];
	$img=$_SESSION['zid']['img'];
	$name=$_SESSION['zid']['name'];