<?php
return array (
  'isinstall' => 1,
);
?>